#include <yaml-cpp/yaml.h>

#include <Eigen/Dense>
#include <opencv2/core/eigen.hpp>
#include <opencv2/opencv.hpp>
#include <vector>

#include "biaoding_common.hpp"

const std::string keys =
  "{help h usage ?     |                              | 输出命令行参数说明}"
  "{config-path       | configs/biaoding.yaml         | yaml配置文件路径 }"
  "{input-folder      | assets/biaoding/handeye       | 输入文件夹路径 }";

int main(int argc, char * argv[])
{
  cv::CommandLineParser cli(argc, argv, keys);
  if (cli.has("help")) {
    cli.printMessage();
    return 0;
  }

  auto config_path = cli.get<std::string>("config-path");
  auto input_folder = cli.get<std::string>("input-folder");

  auto yaml = YAML::LoadFile(config_path);
  auto pattern_size = biaoding::read_pattern_size(yaml);
  auto square_size_mm = biaoding::read_square_size_mm(yaml);
  auto R_gimbal2imubody = biaoding::read_R_gimbal2imubody(yaml);
  auto camera_matrix = biaoding::read_camera_matrix(yaml);
  auto distort_coeffs = biaoding::read_distort_coeffs(yaml);
  auto board_points = biaoding::chessboard_points(pattern_size, square_size_mm);

  std::vector<cv::Mat> R_gimbal2world_list;
  std::vector<cv::Mat> t_gimbal2world_list;
  std::vector<cv::Mat> rvecs;
  std::vector<cv::Mat> tvecs;

  for (int i = 1; true; ++i) {
    auto image_path = fmt::format("{}/{}.jpg", input_folder, i);
    auto q_path = fmt::format("{}/{}.txt", input_folder, i);

    auto image = cv::imread(image_path);
    if (image.empty()) break;

    auto q = biaoding::read_q(q_path);
    auto R_gimbal2world = biaoding::q_to_gimbal_world(q, R_gimbal2imubody);

    std::vector<cv::Point2f> corners;
    bool success = biaoding::detect_chessboard(image, pattern_size, corners);

    auto display = image.clone();
    cv::drawChessboardCorners(display, pattern_size, corners, success);
    cv::resize(display, display, {}, 0.5, 0.5);
    cv::imshow("biaoding_calibrate_handeye", display);
    cv::waitKey(0);

    fmt::print("[{}] {}\n", success ? "success" : "failure", image_path);
    if (!success) continue;

    cv::Mat R_gimbal2world_cv;
    cv::eigen2cv(R_gimbal2world, R_gimbal2world_cv);

    cv::Mat rvec, tvec;
    cv::solvePnP(
      board_points, corners, camera_matrix, distort_coeffs, rvec, tvec, false, cv::SOLVEPNP_IPPE);

    R_gimbal2world_list.emplace_back(R_gimbal2world_cv);
    t_gimbal2world_list.emplace_back((cv::Mat_<double>(3, 1) << 0, 0, 0));
    rvecs.emplace_back(rvec);
    tvecs.emplace_back(tvec);
  }

  if (R_gimbal2world_list.size() < 3) {
    throw std::runtime_error("At least 3 valid image-quaternion pairs are required.");
  }

  cv::Mat R_camera2gimbal, t_camera2gimbal;
  cv::calibrateHandEye(
    R_gimbal2world_list, t_gimbal2world_list, rvecs, tvecs, R_camera2gimbal, t_camera2gimbal);
  t_camera2gimbal /= 1e3;

  Eigen::Matrix3d R_camera2gimbal_eigen;
  cv::cv2eigen(R_camera2gimbal, R_camera2gimbal_eigen);
  Eigen::Matrix3d R_gimbal2ideal{{0, -1, 0}, {0, 0, -1}, {1, 0, 0}};
  Eigen::Matrix3d R_camera2ideal = R_gimbal2ideal * R_camera2gimbal_eigen;
  Eigen::Vector3d camera_ypr = tools::eulers(R_camera2ideal, 1, 0, 2) * 57.3;

  std::vector<double> R_camera2gimbal_data(
    R_camera2gimbal.begin<double>(), R_camera2gimbal.end<double>());
  std::vector<double> t_camera2gimbal_data(
    t_camera2gimbal.begin<double>(), t_camera2gimbal.end<double>());

  YAML::Emitter out;
  out << YAML::BeginMap;
  out << YAML::Key << "R_gimbal2imubody" << YAML::Value << YAML::Flow
      << std::vector<double>{
           R_gimbal2imubody(0, 0), R_gimbal2imubody(0, 1), R_gimbal2imubody(0, 2),
           R_gimbal2imubody(1, 0), R_gimbal2imubody(1, 1), R_gimbal2imubody(1, 2),
           R_gimbal2imubody(2, 0), R_gimbal2imubody(2, 1), R_gimbal2imubody(2, 2)};
  out << YAML::Newline;
  out << YAML::Comment(fmt::format(
    "相机同理想情况的偏角: yaw{:.2f} pitch{:.2f} roll{:.2f} degree", camera_ypr[0],
    camera_ypr[1], camera_ypr[2]));
  out << YAML::Key << "R_camera2gimbal" << YAML::Value << YAML::Flow << R_camera2gimbal_data;
  out << YAML::Key << "t_camera2gimbal" << YAML::Value << YAML::Flow << t_camera2gimbal_data;
  out << YAML::EndMap;

  fmt::print("\n{}\n", out.c_str());
  return 0;
}

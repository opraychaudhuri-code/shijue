#include <yaml-cpp/yaml.h>

#include <opencv2/opencv.hpp>
#include <vector>

#include "biaoding_common.hpp"

const std::string keys =
  "{help h usage ?     |                              | 输出命令行参数说明}"
  "{config-path       | configs/biaoding.yaml         | yaml配置文件路径 }"
  "{input-folder      | assets/biaoding/intrinsics   | 输入文件夹路径 }";

int main(int argc, char * argv[])
{
  cv::CommandLineParser cli(argc, argv, keys);
  if (cli.has("help")) {
    cli.printMessage();
    return 0;
  }

  auto config_path = cli.get<std::string>("config-path");
  auto input_folder = cli.get<std::string>("input-folder");

  auto yaml = YAML::LoadFile(config_path);
  auto pattern_size = biaoding::read_pattern_size(yaml);
  auto square_size_mm = biaoding::read_square_size_mm(yaml);
  auto board_points = biaoding::chessboard_points(pattern_size, square_size_mm);

  cv::Size image_size;
  std::vector<std::vector<cv::Point3f>> obj_points;
  std::vector<std::vector<cv::Point2f>> img_points;

  for (int i = 1; true; ++i) {
    auto image_path = fmt::format("{}/{}.jpg", input_folder, i);
    auto image = cv::imread(image_path);
    if (image.empty()) break;

    image_size = image.size();

    std::vector<cv::Point2f> corners;
    bool success = biaoding::detect_chessboard(image, pattern_size, corners);

    auto display = image.clone();
    cv::drawChessboardCorners(display, pattern_size, corners, success);
    cv::resize(display, display, {}, 0.5, 0.5);
    cv::imshow("biaoding_calibrate_intrinsics", display);
    cv::waitKey(0);

    fmt::print("[{}] {}\n", success ? "success" : "failure", image_path);
    if (!success) continue;

    obj_points.emplace_back(board_points);
    img_points.emplace_back(corners);
  }

  if (obj_points.size() < 3) {
    throw std::runtime_error("At least 3 valid images are required for intrinsic calibration.");
  }

  cv::Mat camera_matrix, distort_coeffs;
  std::vector<cv::Mat> rvecs, tvecs;
  auto criteria =
    cv::TermCriteria(cv::TermCriteria::COUNT | cv::TermCriteria::EPS, 100, DBL_EPSILON);

  cv::calibrateCamera(
    obj_points, img_points, image_size, camera_matrix, distort_coeffs, rvecs, tvecs,
    cv::CALIB_FIX_K3, criteria);

  auto error = biaoding::mean_reprojection_error(
    obj_points, img_points, camera_matrix, distort_coeffs, rvecs, tvecs);

  std::vector<double> camera_matrix_data(
    camera_matrix.begin<double>(), camera_matrix.end<double>());
  std::vector<double> distort_coeffs_data(
    distort_coeffs.begin<double>(), distort_coeffs.end<double>());

  YAML::Emitter out;
  out << YAML::BeginMap;
  out << YAML::Comment(fmt::format("重投影误差: {:.4f}px", error));
  out << YAML::Key << "camera_matrix" << YAML::Value << YAML::Flow << camera_matrix_data;
  out << YAML::Key << "distort_coeffs" << YAML::Value << YAML::Flow << distort_coeffs_data;
  out << YAML::EndMap;

  fmt::print("\n{}\n", out.c_str());
  return 0;
}

#include <yaml-cpp/yaml.h>

#include <filesystem>
#include <opencv2/opencv.hpp>

#include "biaoding_common.hpp"
#include "io/camera.hpp"
#include "io/gimbal/gimbal.hpp"
#include "tools/img_tools.hpp"
#include "tools/logger.hpp"

const std::string keys =
  "{help h usage ?     |                              | 输出命令行参数说明}"
  "{config-path       | configs/biaoding.yaml         | yaml配置文件路径 }"
  "{output-folder     | assets/biaoding/handeye      | 输出文件夹路径 }";

int main(int argc, char * argv[])
{
  cv::CommandLineParser cli(argc, argv, keys);
  if (cli.has("help")) {
    cli.printMessage();
    return 0;
  }

  auto config_path = cli.get<std::string>("config-path");
  auto output_folder = cli.get<std::string>("output-folder");

  auto yaml = YAML::LoadFile(config_path);
  auto pattern_size = biaoding::read_pattern_size(yaml);
  auto R_gimbal2imubody = biaoding::read_R_gimbal2imubody(yaml);

  std::filesystem::create_directories(output_folder);

  io::Gimbal gimbal(config_path);
  io::Camera camera(config_path);
  cv::Mat image;
  std::chrono::steady_clock::time_point timestamp;
  int count = 0;

  tools::logger()->info(
    "棋盘格内角点: {} x {}, 按 s 保存, 按 q 退出", pattern_size.width, pattern_size.height);

  while (true) {
    camera.read(image, timestamp);
    auto q = gimbal.q(timestamp);
    auto R_gimbal2world = biaoding::q_to_gimbal_world(q, R_gimbal2imubody);
    auto ypr = tools::eulers(R_gimbal2world, 2, 1, 0) * 57.3;

    std::vector<cv::Point2f> corners;
    bool success = biaoding::detect_chessboard(image, pattern_size, corners);

    auto display = image.clone();
    cv::drawChessboardCorners(display, pattern_size, corners, success);
    tools::draw_text(display, fmt::format("yaw   {:.2f}", ypr[0]), {30, 40}, {0, 0, 255});
    tools::draw_text(display, fmt::format("pitch {:.2f}", ypr[1]), {30, 80}, {0, 0, 255});
    tools::draw_text(display, fmt::format("roll  {:.2f}", ypr[2]), {30, 120}, {0, 0, 255});
    cv::resize(display, display, {}, 0.5, 0.5);

    cv::imshow("biaoding_capture_handeye", display);
    auto key = cv::waitKey(1);
    if (key == 'q') break;
    if (key != 's') continue;

    if (!success) {
      tools::logger()->warn("当前帧未检测到棋盘格，未保存。");
      continue;
    }

    ++count;
    auto image_path = fmt::format("{}/{}.jpg", output_folder, count);
    auto q_path = fmt::format("{}/{}.txt", output_folder, count);
    cv::imwrite(image_path, image);
    biaoding::write_q(q_path, q);
    tools::logger()->info("[{}] saved {} and {}", count, image_path, q_path);
  }

  return 0;
}

#include <yaml-cpp/yaml.h>

#include <filesystem>
#include <opencv2/opencv.hpp>

#include "biaoding_common.hpp"
#include "io/camera.hpp"
#include "tools/img_tools.hpp"
#include "tools/logger.hpp"

const std::string keys =
  "{help h usage ?     |                              | 输出命令行参数说明}"
  "{config-path       | configs/biaoding.yaml         | yaml配置文件路径 }"
  "{output-folder     | assets/biaoding/intrinsics    | 输出文件夹路径 }";

int main(int argc, char * argv[])
{
  cv::CommandLineParser cli(argc, argv, keys);
  if (cli.has("help")) {
    cli.printMessage();
    return 0;
  }

  auto config_path = cli.get<std::string>("config-path");
  auto output_folder = cli.get<std::string>("output-folder");

  auto yaml = YAML::LoadFile(config_path);
  auto pattern_size = biaoding::read_pattern_size(yaml);

  std::filesystem::create_directories(output_folder);

  io::Camera camera(config_path);
  cv::Mat image;
  std::chrono::steady_clock::time_point timestamp;
  int count = 0;

  tools::logger()->info(
    "棋盘格内角点: {} x {}, 按 s 保存, 按 q 退出", pattern_size.width, pattern_size.height);

  while (true) {
    camera.read(image, timestamp);

    std::vector<cv::Point2f> corners;
    bool success = biaoding::detect_chessboard(image, pattern_size, corners);

    auto display = image.clone();
    cv::drawChessboardCorners(display, pattern_size, corners, success);
    tools::draw_text(display, success ? "board detected" : "board not detected", {30, 40});
    cv::resize(display, display, {}, 0.5, 0.5);

    cv::imshow("biaoding_capture_intrinsics", display);
    auto key = cv::waitKey(1);
    if (key == 'q') break;
    if (key != 's') continue;

    if (!success) {
      tools::logger()->warn("当前帧未检测到棋盘格，未保存。");
      continue;
    }

    ++count;
    auto image_path = fmt::format("{}/{}.jpg", output_folder, count);
    cv::imwrite(image_path, image);
    tools::logger()->info("[{}] saved {}", count, image_path);
  }

  return 0;
}
